(() => {
  const COLS = 64, ROWS = 42;
  const canvas = document.getElementById('bouquet');
  const ctx = canvas.getContext('2d');
  const COLOR = {
    tip: '#F3E9DC', blush: '#F2B8C6', stamen: '#F2A93B',
    stem: '#7DB48B', leaf: '#4E8A63', ribbon: '#E8D9A8', bud: '#E9D3C7'
  };
  const ANCHOR = { x: 32, y: 33 };
  const lilies = [
    { x: 17, y: 21, R: 9,   rot: 0.3, ph: 1.0 },
    { x: 47, y: 22, R: 9.5, rot: 0.9, ph: 2.1 },
    { x: 32, y: 12, R: 12,  rot: 0.1, ph: 0.0 }
  ];
  const buds = [
    { x: 10, y: 14, len: 8, ang: -0.35, ph: 0.7 },
    { x: 54, y: 15, len: 7, ang: 0.4,  ph: 1.6 }
  ];
  const leaves = [
    { a: -2.64, L: 17, w: 2.2, ph: 0.2 },
    { a: -0.50, L: 16, w: 2.2, ph: 1.1 },
    { a: -2.15, L: 12, w: 1.8, ph: 2.0 },
    { a: -1.00, L: 12, w: 1.8, ph: 2.9 }
  ];

  let cw = 10, ch = 20, width = 640;
  const chars = new Array(COLS * ROWS);
  const cols = new Array(COLS * ROWS);

  function put(x, y, c, col) {
    x = Math.round(x); y = Math.round(y);
    if (x < 0 || y < 0 || x >= COLS || y >= ROWS) return;
    chars[y * COLS + x] = c;
    cols[y * COLS + x] = col;
  }

  function slashFor(dx, dyv) {
    const a = Math.atan2(dyv, dx);
    if (Math.abs(Math.cos(a)) < 0.38) return '|';
    return (dx * dyv > 0) ? '\\' : '/';
  }

  function drawLeaf(l, t) {
    const a = l.a + Math.sin(t * 0.7 + l.ph) * 0.04;
    const ca = Math.cos(a), sa = Math.sin(a);
    const mid = slashFor(ca, sa);
    for (let s = 0; s <= 1; s += 1 / (l.L * 1.5)) {
      const wv = l.w * Math.sin(Math.PI * s);
      for (let v = -wv; v <= wv; v += 0.5) {
        const px = ANCHOR.x + ca * s * l.L - sa * v;
        const py = ANCHOR.y + (sa * s * l.L + ca * v) / 2;
        const edge = Math.abs(v) > wv * 0.7;
        put(px, py, Math.abs(v) < 0.3 ? mid : edge ? "'" : ':', COLOR.leaf);
      }
    }
  }

  function drawStem(tx, ty, t, ph) {
    const sway = Math.sin(t * 0.8 + ph) * 1.2;
    const cx = ANCHOR.x + (tx - ANCHOR.x) * 0.2 + sway;
    const cy = ANCHOR.y + (ty - ANCHOR.y) * 0.55;
    for (let s = 0; s <= 1; s += 1 / 70) {
      const u = 1 - s;
      const px = u * u * ANCHOR.x + 2 * u * s * cx + s * s * tx;
      const py = u * u * ANCHOR.y + 2 * u * s * cy + s * s * ty;
      const dx = 2 * u * (cx - ANCHOR.x) + 2 * s * (tx - cx);
      const dy = 2 * u * (cy - ANCHOR.y) + 2 * s * (ty - cy);
      put(px, py, slashFor(dx, dy * 2), COLOR.stem);
    }
  }

  function drawBud(b, t) {
    const ang = b.ang + Math.sin(t * 0.7 + b.ph) * 0.05;
    const dx = Math.sin(ang), dy = -Math.cos(ang);
    const px = -dy, py = dx;
    for (let s = 0; s <= 1; s += 1 / (b.len * 2)) {
      const wv = b.len * 0.22 * Math.sin(Math.PI * Math.pow(s, 0.8));
      for (let v = -wv; v <= wv; v += 0.5) {
        const x = b.x + dx * s * b.len + px * v;
        const y = b.y + (dy * s * b.len + py * v) / 2 * 2 * 0.5;
        put(x, y, Math.abs(v) > wv * 0.75 ? 'o' : 'O', COLOR.bud);
      }
    }
    put(b.x + dx * b.len, b.y + dy * b.len * 0.5, '^', COLOR.tip);
  }

  function drawLily(l, t) {
    const cx = l.x + Math.sin(t * 0.8 + l.ph) * 1.1;
    const cy = l.y + Math.cos(t * 0.6 + l.ph) * 0.4;
    const R = l.R * (0.95 + 0.05 * Math.sin(t * 1.1 + l.ph));
    const rot = l.rot + t * 0.05;
    const x0 = Math.floor(cx - R) - 1, x1 = Math.ceil(cx + R) + 1;
    const y0 = Math.floor(cy - R / 2) - 1, y1 = Math.ceil(cy + R / 2) + 1;
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const dx = x - cx, dy = (y - cy) * 2;
        const r = Math.hypot(dx, dy);
        if (r < 1) continue;
        const th = Math.atan2(dy, dx);
        const pr = R * Math.pow(Math.abs(Math.cos(3 * (th - rot))), 1.7);
        if (r > pr) continue;
        const k = r / pr;
        const c = k > 0.85 ? '.' : k > 0.65 ? ':' : k > 0.4 ? 'o' : k > 0.2 ? 'O' : '#';
        put(x, y, c, k < 0.45 ? COLOR.blush : COLOR.tip);
      }
    }
    for (let k = 0; k < 6; k++) {
      const a = rot + Math.PI / 6 + k * Math.PI / 3;
      const len = Math.max(2, Math.round(R * 0.42));
      for (let s = 1; s <= len; s++) {
        put(cx + Math.cos(a) * s, cy + Math.sin(a) * s / 2, s === len ? '*' : '.', COLOR.stamen);
      }
    }
    put(cx, cy, '@', COLOR.stamen);
  }

  function drawBundle() {
    for (let y = 34; y < ROWS; y++) {
      const half = y < 37 ? 2 : 1;
      put(ANCHOR.x - half, y, '|', COLOR.stem);
      put(ANCHOR.x, y, '|', COLOR.stem);
      put(ANCHOR.x + half, y, '|', COLOR.stem);
    }
    for (let x = 27; x <= 37; x++) put(x, 36, '=', COLOR.ribbon);
    put(32, 36, '8', COLOR.ribbon);
    put(30, 37, '/', COLOR.ribbon); put(34, 37, '\\', COLOR.ribbon);
    put(29, 38, '/', COLOR.ribbon); put(35, 38, '\\', COLOR.ribbon);
  }

  function render(t) {
    chars.fill(undefined);
    leaves.forEach(l => drawLeaf(l, t));
    lilies.forEach(l => drawStem(l.x, l.y, t, l.ph));
    buds.forEach(b => drawStem(b.x, b.y, t, b.ph));
    drawBundle();
    buds.forEach(b => drawBud(b, t));
    lilies.forEach(l => drawLily(l, t));
    ctx.clearRect(0, 0, width, ch * ROWS);
    for (let i = 0; i < chars.length; i++) {
      if (!chars[i]) continue;
      ctx.fillStyle = cols[i];
      ctx.fillText(chars[i], (i % COLS) * cw + cw / 2, Math.floor(i / COLS) * ch + ch / 2);
    }
  }

  function resize() {
    width = Math.min(canvas.parentElement.clientWidth, 720);
    const dpr = window.devicePixelRatio || 1;
    cw = width / COLS;
    ch = cw * 2;
    canvas.style.width = width + 'px';
    canvas.style.height = ch * ROWS + 'px';
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(ch * ROWS * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.font = (cw * 1.65) + 'px "DejaVu Sans Mono", Menlo, Consolas, monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
  }

  const still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let last = 0;
  function loop(ms) {
    if (ms - last > 45) { last = ms; render(ms / 1000); }
    requestAnimationFrame(loop);
  }

  resize();
  window.addEventListener('resize', () => { resize(); if (still) render(0); });
  if (still) render(0); else requestAnimationFrame(loop);
})();
